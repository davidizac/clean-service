require('dotenv').config({ path: require('path').join(__dirname, '.env') })
const startcleeser = require('./helpers')

startcleeser()
