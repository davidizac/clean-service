module.exports.setGlobals = function() {
  global.cleeser = {
    CATEGORIES: ['Costumes', 'Jupes', 'Manteaux', 'Pantalons', 'Robes', 'Tappiseries']
  }
}
