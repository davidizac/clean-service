const BaseError = require('./base')
module.exports = class AccessDeniedError extends BaseError {}
