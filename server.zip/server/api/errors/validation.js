const BaseError = require('./base')
module.exports = class ValidationError extends BaseError {}
